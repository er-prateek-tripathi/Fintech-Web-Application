import { createContext } from "react";

const AdvancedSearchContext = createContext();

export default AdvancedSearchContext;
