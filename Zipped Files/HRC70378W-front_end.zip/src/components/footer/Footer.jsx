import React from "react";

const footer = () => {
  return (
    <p className="footer">
      <a href="#">Privacy Policy </a> | &#169; highRadius Corporation. All
      Rights reserved
    </p>
  );
};

export default footer;
